## Mini-Geständnisse  

**1. Definition / Beschreibung**  
Zugeständnisse kleiner, irrelevanter Handlungen, um ehrlich zu wirken.

**2. Bedeutung**  
- Vertrauensgewinn, Ablenkung von Hauptvorwürfen  
- „Ehrlichkeits-Display“ ohne Substanz

**3. Varianten**  
[in Arbeit]

**4. Hintergrund**  
Typisch: triviale Eingeständnisse (z. B. Berühren eines Gegenstands), um das Gegenüber gnädiger zu stimmen.

**5. Verstärkende Verhaltensweisen**  
- Höflichkeitsanstieg  
- Lebenswandel-Ausrede

**6. Gegenläufige Verhaltensweisen**  
- direkte, substanzielle Antworten zur Sache

**7. Beispiele**  
[in Arbeit]

**8. Sonstiges**  
Bei Chase Hughes CHEM: Miniconfessions, Mc, 120

**9. Literatur**  
- CHEM2017 S. 64
