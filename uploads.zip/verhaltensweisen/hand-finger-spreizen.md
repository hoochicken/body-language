## Finger-Spreizen  

**1. Definition / Beschreibung**  
Die Finger werden gespreizt und von der Handfläche weg bewegt.  

**2. Bedeutung**  
- Offenheit und Entspannung  
- in manchen Kontexten Anzeichen von Stress/Angst (insb. mit Genitalschutz kombiniert)  

**3. Varianten**  
[in Arbeit]  

**4. Hintergrund**  
Finger-Spreizen ist meist ein harmloser Ausdruck leichter Erregung oder Offenheit, kann aber auch Schutzreaktionen begleiten.  

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]  

**6. Gegenläufige Verhaltensweisen**  
- geschlossene Faust  
- entspannte, lose Fingerhaltung  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Digital Extension, De, 39  

**9. Literatur**  
- CHEM2017 S. 41  
