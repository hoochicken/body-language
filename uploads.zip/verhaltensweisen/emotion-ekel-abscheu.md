## Ekel / Abscheu  

**1. Definition / Beschreibung**  
Universaler Gesichtsausdruck: Gesichtszüge verziehen sich zur Nase hin.  

**2. Bedeutung**  
- emotionaler oder physischer Ekel  
- tritt auf, wenn das Thema oder der Reiz als widerlich erlebt wird  

**3. Varianten**  
[in Arbeit]  

**4. Hintergrund**  
Ekel wird selten simuliert und ist daher ein verlässlicher Indikator. Nasenflügelerweiterung ist die gegenteilige Geste (Luft einatmen vs. Abwehr).  

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]  

**6. Gegenläufige Verhaltensweisen**  
- Nasenflügel-Erweiterung (Atmungserleichterung)  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Disgust, Dg, 31  

**9. Literatur**  
- CHEM2017 S. 39  
