## Ziffer Vier  

**1. Definition / Beschreibung**  
Beim Sitzen wird ein Knöchel über das andere Knie gelegt; der Fuß zeigt sichtbar nach außen.  

**2. Bedeutung**  
- Entspannung  
- situatives Selbstvertrauen  
- in manchen Kulturen auch sexuelle Bereitschaft  

**3. Varianten**  
[in Arbeit]  

**4. Hintergrund**  
Die exponierte Fußsohle kann in vielen Kulturen (z. B. arabische, asiatische) als respektlos gelten. Konfliktgeste: Griff ans eigene Knie → Gespräch beenden wollen.  

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]  

**6. Gegenläufige Verhaltensweisen**  
[in Arbeit]  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Figure-Four Leg Cross, 4, 58  

**9. Literatur**  
- CHEM2017 S. 47  
- JNML2013 S. 88  
