## Objekt im Mund

**1. Definition / Beschreibung**  
Ein Objekt/Finger überschreitet die Lippenlinie und gelangt in den Mund.

**2. Bedeutung**  
- Bedürfnis nach Absicherung/Selbstberuhigung  
- Unsicherheit

**3. Varianten**  
[in Arbeit]

**4. Hintergrund**  
Orale Selbstberührung dient der Stressreduktion; geschlechtsunabhängig verbreitet.

**5. Verstärkende Verhaltensweisen**  
- eng an den Körper gezogene Arme  
- Selbstberührungen im Gesicht

**6. Gegenläufige Verhaltensweisen**  
- offene Hände, weg vom Gesicht  
- ruhige Atmung, stabile Stimme

**7. Beispiele**  
[in Arbeit]

**8. Sonstiges**  
Bei Chase Hughes CHEM: Object in Mouth, Om, 8

**9. Literatur**  
- CHEM2017 S. 29
