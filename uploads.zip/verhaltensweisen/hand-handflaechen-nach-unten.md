## Handflächen nach unten  

**1. Definition / Beschreibung**  
Handflächen werden nach unten gedreht/gerichtet.

**2. Bedeutung**  
- geringe Offenheit/Transparenz  
- Abwehrhaltung, Unwille zur Kooperation  
- Hinweis auf Informationszurückhaltung

**3. Varianten**  
[in Arbeit]

**4. Hintergrund**  
Häufig, wenn Personen sich bedroht fühlen oder auf Widersprüche hingewiesen werden; im sozialen Alltag auch als stiller Widerspruch.

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]

**6. Gegenläufige Verhaltensweisen**  
- Handflächen zeigen (Offenheit)

**7. Beispiele**  
[in Arbeit]

**8. Sonstiges**  
Bei Chase Hughes CHEM: Palms Down, Pdn, 72

**9. Literatur**  
- CHEM2017 S. 51  
- JNML2013 S. 244
