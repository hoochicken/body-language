## Anheben des Adamsapfels

**1. Definition / Beschreibung**  
Der Adamsapfel (Kehlkopf) bewegt sich sichtbar nach oben; oft zusammen mit Schlucken.

**2. Bedeutung**  
- Stress/innere Ablehnung  
- kein typisches Furchtgesicht begleitend

**3. Varianten**  
- Adamsapfel hebt sich mit Schluckreflex  
- Adamsapfel hebt sich ohne Schlucken (emotionale Reaktion)

**4. Hintergrund**  
Anspannung verengt den Halsbereich; sichtbare Kehlkopfbewegungen sind häufige Stressmarker.

**5. Verstärkende Verhaltensweisen**  
- Räuspern  
- trockener Mund, Schlucken  
- Blickabwendung

**6. Gegenläufige Verhaltensweisen**  
- entspannter Hals  
- ruhige Atmung, flüssige Sprache

**7. Beispiele**  
[in Arbeit]

**8. Sonstiges**  
Bei Chase Hughes CHEM: Adam's Apple Raise, Aa, 20

**9. Literatur**  
- CHEM2017 S. 34
