## Lippenkompression

**1. Definition / Beschreibung**  
Die Lippen werden fest aufeinandergepresst.

**2. Bedeutung**  
- Zurückhalten von Meinung/Information  
- innere Spannung, soziale Hemmung  
- in kritischen Vernehmungsphasen mögliches Täuschungsindikator (kontextabhängig)

**3. Varianten**  
[in Arbeit]

**4. Hintergrund**  
Die gepressten Lippen bilden eine „Barriere“ gegen das Sprechen; Relevanz steigt, wenn gerade belastende Hypothesen/Abläufe skizziert werden.

**5. Verstärkende Verhaltensweisen**  
- trockener Mund, Schlucken  
- angespannte Kiefermuskulatur  
- ausweichender Blick

**6. Gegenläufige Verhaltensweisen**  
- lockere Lippen  
- flüssiges Sprechen

**7. Beispiele**  
[in Arbeit]

**8. Sonstiges**  
Bei Chase Hughes CHEM: Lip compression, Lc, 5

**9. Literatur**  
- CHEM2017 S. 28  
- JNML2013 S. 202f  
- JNML2013 S. 207
