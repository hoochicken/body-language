## Fäuste auf dem Tisch  

**1. Definition / Beschreibung**  
Beide Fäuste werden sichtbar (kräftig) auf die Tischplatte gesetzt.

**2. Bedeutung**  
- stark aggressiver/dominanter Impuls  
- kann ehrliche Empörung oder täuschungsbedingte Aggression anzeigen (Timing beachten)

**3. Varianten**  
[in Arbeit]

**4. Hintergrund**  
Kongruenzprüfung: Bei ehrlichen Reaktionen sind verbale/gestische Komponenten zeitgleich; bei Täuschung oft Mikroversatz.

**5. Verstärkende Verhaltensweisen**  
- Kieferpressen, Stirnrunzeln  
- Vorlehnen des Torsos

**6. Gegenläufige Verhaltensweisen**  
- offene Handflächen, ruhige Gestik

**7. Beispiele**  
[in Arbeit]

**8. Sonstiges**  
Bei Chase Hughes CHEM: Fists on Table, Ftb, 104

**9. Literatur**  
- CHEM2017 S. 60
