## Schutzgesten  

**1. Definition / Beschreibung**  
Körperteile oder Objekte werden vor den Körper gehalten, um vitale Bereiche zu schützen.  

**2. Bedeutung**  
- Angst  
- Unsicherheit  
- Abwehr  

**3. Varianten**  
[in Arbeit]  

**4. Hintergrund**  
Arme, Hände oder Gegenstände wie Tassen dienen als „Schild“. In Kombination mit Kiefermahlen oft Ausdruck verdeckter Wut.  

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]  

**6. Gegenläufige Verhaltensweisen**  
- offene Haltung, keine Barrieren  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Protecting Gestures, Pr, 35  

**9. Literatur**  
- CHEM2017 S. 40  
