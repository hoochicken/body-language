## Finger an die Nase  

**1. Definition / Beschreibung**  
Ein Finger tippt/streicht an/über die Nase (Mund bleibt unbedeckt).  

**2. Bedeutung**  
- Variante der „Mund verdecken“-Familie  
- hoher Täuschungsbezug **nur** in Kombination mit weiteren hochrangigen Täuschungsmarkern  

**3. Varianten**  
[in Arbeit]  

**4. Hintergrund**  
Der Impuls, den Mund zu bedecken, wird „umgeleitet“; deshalb erhöht in Täuschungskontexten relevant, aber nicht isoliert beweisend.  

**5. Verstärkende Verhaltensweisen**  
- Blickabwendung  
- Stimmbrüche, Räuspern  

**6. Gegenläufige Verhaltensweisen**  
- offene Mundpartie, keine Hand-am-Gesicht-Gesten  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Finger to Nose, Fns, 92  

**9. Literatur**  
- CHEM2017 S. 57  
