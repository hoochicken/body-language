## Interaktion mit Fremdeigentum  

**1. Definition / Beschreibung**  
Bewusstes/ungezwungenes Berühren, Nutzen oder Umplatzieren fremder Gegenstände.  

**2. Bedeutung**  
- hohes Behagen und soziale Dominanz  
- teils Verachtung/geringe Wertschätzung für die Gruppe/den Eigentümer  

**3. Varianten**  
- freiwillige Interaktion  
- „erlaubte“ Interaktion (nach Freigabe)  

**4. Hintergrund**  
Umgang mit Fremdeigentum spiegelt die soziale Haltung: respektvoll vs. achtlos.  

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]  

**6. Gegenläufige Verhaltensweisen**  
- Hände bei sich behalten, Distanz zu Objekten wahren  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Interaction with Other's Property, Opi, 93  

**9. Literatur**  
- CHEM2017 S. 57  
