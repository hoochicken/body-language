## Führungsgesten  

**1. Definition / Beschreibung**  
Gesten, die verwendet werden, um Aufmerksamkeit zu lenken oder den Weg zu weisen.  

**2. Bedeutung**  
- zeigen, wo sich jemand oder etwas befindet  
- leiten den Blick oder die Bewegung des Gegenübers  
- häufig in Service-Situationen (z. B. Kellner, Gastgeber)  

**3. Varianten**  
- Führungsgeste mit der Hand  
- Führungsgeste mit dem Kopf  
- Führungsgeste unter Zurückweichen (man gibt den Weg frei)  

**4. Hintergrund**  
Führungsgesten gehören zur grundlegenden nonverbalen Kommunikation und verstärken Orientierung und Höflichkeit.  

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]  

**6. Gegenläufige Verhaltensweisen**  
[in Arbeit]  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Guiding Gesture, Gg, 21  

**9. Literatur**  
- CHEM2017 S. 34  
