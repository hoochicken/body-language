## Lufteinzug durch Zähne

**1. Definition / Beschreibung**  
Luft wird hörbar/gezielt durch die Zähne eingesogen.

**2. Bedeutung**  
- in Gesprächen oft als aggressiv/antisozial wahrgenommen  
- kann Herausforderung, Respektlosigkeit oder Verachtung ausdrücken

**3. Varianten**  
- Zähne-Saugen als antisoziales Signal  
- Zähne-Saugen als Hygiene-/Reinigungsbewegung

**4. Hintergrund**  
Die akustisch auffällige Handlung markiert Distanz/Protest; Kontext entscheidet über soziale Bewertung.

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]

**6. Gegenläufige Verhaltensweisen**  
[in Arbeit]

**7. Beispiele**  
[in Arbeit]

**8. Sonstiges**  
Bei Chase Hughes CHEM: Teeth Sucking, Ts, 6

**9. Literatur**  
- CHEM2017 S. 28
