## Fußkreuz  

**1. Definition / Beschreibung**  
Im Sitzen werden die Füße/Knöchel unter dem Stuhl kreuzförmig übereinandergelegt.  

**2. Bedeutung**  
- Informationszurückhaltung  
- Wunsch, etwas zu verbergen  
- Unbehagen  

**3. Varianten**  
[in Arbeit]  

**4. Hintergrund**  
Das Lösen der Kreuzung (z. B. durch Haltungswechsel oder Aufstehen) kann die Gesprächsbereitschaft erhöhen.  

**5. Verstärkende Verhaltensweisen**  
- zusammengepresste Knie/Beine  
- gesenkte Kopf- oder Torsoposition  

**6. Gegenläufige Verhaltensweisen**  
- Füße parallel, locker nebeneinander  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Locked Ankle, La, 84  

**9. Literatur**  
[in Arbeit]  
