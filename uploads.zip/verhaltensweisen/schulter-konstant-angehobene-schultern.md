## Konstant angehobene Schultern  

**1. Definition / Beschreibung**  
Die Schultern werden dauerhaft hochgezogen gehalten.  

**2. Bedeutung**  
- soziale Angst  
- Befangenheit  
- Schutzreaktion  

**3. Varianten**  
[in Arbeit]  

**4. Hintergrund**  
Das automatische Hochziehen der Schultern schützt den Hals und andere lebenswichtige Bereiche.  

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]  

**6. Gegenläufige Verhaltensweisen**  
- entspannte, gesenkte Schultern  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Constantly raised shoulders, Cr, 52  

**9. Literatur**  
- CHEM2017 S. 46  
