## Atemfrequenz  

**1. Definition / Beschreibung**  
Anzahl der Atemzüge pro Minute (Erwachsene durchschnittlich ~12/min).

**2. Bedeutung**  
- steigt mit wahrgenommenem Stress  
- Indikator für limbische Aktivierung (Fight/Flight)

**3. Varianten**  
[in Arbeit]

**4. Hintergrund**  
Stress/Kampf-Flucht-Bereitschaft erhöht O₂-Bedarf, daher schnellere Atmung.

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]

**6. Gegenläufige Verhaltensweisen**  
- ruhige, tiefe Atmung

**7. Beispiele**  
[in Arbeit]

**8. Sonstiges**  
Bei Chase Hughes CHEM: Breathing Rate, Bre, 78

**9. Literatur**  
- CHEM2017 S. 53  
- JNML2013 S. 119
