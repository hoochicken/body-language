## Kiefermahlen

**1. Definition / Beschreibung**  
Zähne werden aufeinandergepresst/gerieben; Kiefer- und Schläfenmuskeln treten sichtbar hervor.

**2. Bedeutung**  
- unterdrückte Aggression/Feindseligkeit  
- latent wütende Reaktion auf Thema/Handlung

**3. Varianten**  
[in Arbeit]

**4. Hintergrund**  
Kieferanspannung ist ein typischer Stress-/Wutmarker und kann die Stimm- und Gesichtsmotorik beeinflussen.

**5. Verstärkende Verhaltensweisen**  
- starrer Blick  
- gepresste Lippen  
- angespannter Nacken

**6. Gegenläufige Verhaltensweisen**  
- lockerer Kiefer  
- entspannte Kaumuskulatur

**7. Beispiele**  
[in Arbeit]

**8. Sonstiges**  
Bei Chase Hughes CHEM: Jaw Clenching, Jc, 9

**9. Literatur**  
- CHEM2017 S. 29  
- JNML2013 S. 182
