## Lippen-Einzug

**1. Definition / Beschreibung**  
Die Lippen werden nach innen gezogen und zwischen die Zähne oder in den Mundraum verlagert.

**2. Bedeutung**  
- Unsicherheit, Bedürfnis nach Absicherung  
- Selbstberuhigung

**3. Varianten**  
[in Arbeit]

**4. Hintergrund**  
Verwandt mit oralen Selbstberührungen; unterscheidet sich von der Lippenkompression (Barriere gegen Sprechen).

**5. Verstärkende Verhaltensweisen**  
- Blick abwenden  
- Schultern einziehen

**6. Gegenläufige Verhaltensweisen**  
- neutrale, entspannte Lippenlage  
- ruhige Atmung, klare Stimme

**7. Beispiele**  
[in Arbeit]

**8. Sonstiges**  
Bei Chase Hughes CHEM: Lip Retraction, Lr, 16

**9. Literatur**  
- CHEM2017 S. 32
