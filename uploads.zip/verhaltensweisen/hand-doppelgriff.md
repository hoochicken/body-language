## Doppelgriff  

**1. Definition / Beschreibung**  
Ein Objekt/Körperteil (z. B. Oberschenkel, Kleidungsstück) wird mit beiden Händen gegriffen.

**2. Bedeutung**  
- geschlossene, kontrollierende Geste  
- Bedürfnis nach Sicherheit/Kontrolle  
- häufig bei Vorsicht/Misstrauen

**3. Varianten**  
[in Arbeit]

**4. Hintergrund**  
„Greifen mit beiden Händen“ stabilisiert körperlich und psychisch (Selbstberuhigung).

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]

**6. Gegenläufige Verhaltensweisen**  
- eine Hand locker, die andere frei  
- offene Handflächen

**7. Beispiele**  
[in Arbeit]

**8. Sonstiges**  
Bei Chase Hughes CHEM: Two-handed Grasping, Gr, 66

**9. Literatur**  
- CHEM2017 S. 50
