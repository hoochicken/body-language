## Vertikales Kopfnicken  

**1. Definition / Beschreibung**  
Das wiederholte Senken und Heben des Kopfes auf vertikaler Achse.  

**2. Bedeutung**  
- Zustimmung („Ja“) in den meisten westlichen Kulturen  
- kann als Schutz- oder Barrierverhalten auftreten (Konfliktanzeige)  

**3. Varianten**  
[in Arbeit]  

**4. Hintergrund**  
Vertikales Kopfnicken ist universell, aber mit kulturellen Feinheiten verbunden. In Kombination mit geschlossenen Körperhaltungen (z. B. Beine verschränkt) kann es ambivalent wirken.  

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]  

**6. Gegenläufige Verhaltensweisen**  
- horizontales Kopfschütteln („Nein“)  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Vertical Head Shake, Ye, 23  

**9. Literatur**  
- CHEM2017 S. 35  
