## Beine überkreuz im Stand  

**1. Definition / Beschreibung**  
Überkreuzen der Beine in stehender Position.  

**2. Bedeutung**  
- Behagen und Wohlfühlen in der Situation  
- reduzierte Reaktions- und Bewegungsfähigkeit  

**3. Varianten**  
- Beine gekreuzt im entspannten Stand  
- Wechsel zurück in den zweibeinigen Stand bei Veränderung der Situation (z. B. Eintreten anderer Personen)  

**4. Hintergrund**  
Da das Gleichgewicht eingeschränkt ist, signalisiert diese Haltung Vertrauen in die aktuelle Situation.  

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]  

**6. Gegenläufige Verhaltensweisen**  
- fester, stabiler Stand mit beiden Füßen parallel  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei JNML2013: Beine überkreuz im Stand  

**9. Literatur**  
- JNML2013 S. 83  
