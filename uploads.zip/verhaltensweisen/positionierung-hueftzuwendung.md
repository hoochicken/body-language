## Hüftzuwendung  

**1. Definition / Beschreibung**  
Ausrichtung des Beckens/der Hüfte in Richtung des mentalen Fokus, unabhängig von der Oberkörperausrichtung.

**2. Bedeutung**  
- Hüfte zum Gegenüber: Interesse, Zuwendung  
- Hüfte vom Gegenüber weg: Distanzierungswunsch, Gespräch beenden wollen  
- korreliert oft mit Fußausrichtung

**3. Varianten**  
- Hüfte zeigt zum Interviewenden  
- Hüfte zeigt vom Interviewenden weg

**4. Hintergrund**  
Becken und Füße verraten häufig die wahre Aufmerksamkeitsrichtung. In Kampfsport-Analogien zeigt die Hüfte dorthin, wohin auch Kraft/Impuls gerichtet wird.

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]

**6. Gegenläufige Verhaltensweisen**  
- Oberkörper frontal, Hüfte und Füße klar abgewandt

**7. Beispiele**  
[in Arbeit]

**8. Sonstiges**  
Bei Chase Hughes CHEM: Pelvic Facing, FF, 60

**9. Literatur**  
- CHEM2017 S. 48
