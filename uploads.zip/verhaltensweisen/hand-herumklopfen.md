## Herumklopfen  

**1. Definition / Beschreibung**  
Rhythmisches Klopfen (z. B. mit Fingern) auf Tisch/Armlehne etc.

**2. Bedeutung**  
- Langeweile  
- innerer Monolog/Nachdenken  
- Nervosität  
- Spannungsabfuhr (kontextabhängig)

**3. Varianten**  
[in Arbeit]

**4. Hintergrund**  
Ohne klare Unterscheidungsmerkmale; die Interpretation hängt stark von zeitlichem Kontext und Begleitsignalen ab.

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]

**6. Gegenläufige Verhaltensweisen**  
- ruhige Hände, stilles Sitzen

**7. Beispiele**  
[in Arbeit]

**8. Sonstiges**  
Bei Chase Hughes CHEM: Tapping, Tp, 64

**9. Literatur**  
- CHEM2017 S. 49  
- JNML2013 S. 157
