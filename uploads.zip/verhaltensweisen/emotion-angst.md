## Angst  

**1. Definition / Beschreibung**  
Universaler Gesichtsausdruck: geweitete Augen, angehobene Brauen, horizontales Zurückziehen der Lippen.  

**2. Bedeutung**  
- akute Angstreaktion  
- Stress oder Alarmzustand  

**3. Varianten**  
[in Arbeit]  

**4. Hintergrund**  
Angstgesicht weitet das Sichtfeld und bereitet auf Flucht/Kampf vor. In Kombination mit Gesten wie Arme hinter den Rücken kann es Stolz oder Erregung andeuten.  

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]  

**6. Gegenläufige Verhaltensweisen**  
[in Arbeit]  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Fear, Fr, 32  

**9. Literatur**  
- CHEM2017 S. 39  
