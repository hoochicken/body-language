## Körperhaltung  

**1. Definition / Beschreibung**  
Die generelle Haltung und Ausrichtung des Körpers.  

**2. Bedeutung**  
- aufrechte, vertikale Haltung: Sicherheit, Aufmerksamkeit  
- gebeugte Haltung: Unsicherheit, Rückzug  

**3. Varianten**  
- vertikal, aufrecht  
- konvex, gebeugt  

**4. Hintergrund**  
Die Körperhaltung liefert Baseline-Informationen. Abweichungen davon können Stress, Müdigkeit oder Täuschung anzeigen.  

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]  

**6. Gegenläufige Verhaltensweisen**  
[in Arbeit]  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Posture, Ps, 44  

**9. Literatur**  
- CHEM2017 S. 43  
