## Herumfummeln  

**1. Definition / Beschreibung**  
Unruhige, „zweckfreie“ kleine Bewegungen der Hände/Extremitäten, mit oder ohne Objekt.

**2. Bedeutung**  
- nervöse Energie, Adrenalinabbau  
- Stress/Angst  
- geringe kognitive Ressourcen für Stillhalten

**3. Varianten**  
[in Arbeit]

**4. Hintergrund**  
Je weiter entfernt von Kopf/Zentrum, desto schwerer hemmbar unter Stress (z. B. Fußwippen).

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]

**6. Gegenläufige Verhaltensweisen**  
- ruhige, kontrollierte Mikrobewegungen

**7. Beispiele**  
[in Arbeit]

**8. Sonstiges**  
Bei Chase Hughes CHEM: Fidgeting, Fi, 65

**9. Literatur**  
- CHEM2017 S. 50
