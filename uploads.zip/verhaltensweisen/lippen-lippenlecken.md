## Lippenlecken  

**1. Definition / Beschreibung**  
Befeuchten der Lippen mit der Zunge.  

**2. Bedeutung**  
- Beruhigungsgeste  
- Hinweis auf Nervosität (trockene Lippen durch Stress)  
- manchmal Ausdruck von Erleichterung, wenn man „davongekommen“ ist  

**3. Varianten**  
- Lippen kurz befeuchten  
- sichtbare Zunge beim Lippenlecken  

**4. Hintergrund**  
Beruhigungsgeste, häufig in Prüfungssituationen oder bei Stress. Hängt mit Speichelfluss und Stressregulation zusammen.  

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]  

**6. Gegenläufige Verhaltensweisen**  
- neutrale, entspannte Lippenhaltung  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Behavior Panel: Lippenlecken  

**9. Literatur**  
- JNML2013 S. 207  
