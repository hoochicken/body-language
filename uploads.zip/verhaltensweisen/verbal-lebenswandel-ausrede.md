## Lebenswandel-Ausrede  

**1. Definition / Beschreibung**  
Verweis auf eigenen „guten Charakter“/soziales Engagement als Replik auf Verdacht/Anschuldigung.

**2. Bedeutung**  
- Ablenkung, Image-Management  
- versucht, Vertrauen zu binden statt Frage zu beantworten

**3. Varianten**  
[in Arbeit]

**4. Hintergrund**  
Kein inhaltlicher Bezug zur Frage; manipulative Vertrauensstiftung.

**5. Verstärkende Verhaltensweisen**  
- Höflichkeitsanstieg  
- Kein-Antwort-Aussagen

**6. Gegenläufige Verhaltensweisen**  
- direkte Sachbeantwortung

**7. Beispiele**  
[in Arbeit]

**8. Sonstiges**  
Bei Chase Hughes CHEM: Résumé Statement, Nc, 115

**9. Literatur**  
- CHEM2017 S. 63
