## Wangenstreichen  

**1. Definition / Beschreibung**  
Eine Person streicht über ihre Wange oder reibt diese.  

**2. Bedeutung**  
- Nachdenken, innerer Monolog  
- Neugier  
- in Verbindung mit Verachtung: Gefühl von Überlegenheit  

**3. Varianten**  
[in Arbeit]  

**4. Hintergrund**  
Wangenstreichen ist eine selbstberuhigende und zugleich reflektierende Geste. Im Kontext von Verachtung zeigt sie Abgrenzung oder moralische Distanzierung.  

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]  

**6. Gegenläufige Verhaltensweisen**  
[in Arbeit]  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Chin Stroke, Cs, 41  

**9. Literatur**  
- CHEM2017 S. 42  
