## Freude

**1. Definition / Beschreibung**  
Universaler Gesichtsausdruck: Mundwinkel nach oben; echte Freude zeigt Falten an den Augenwinkeln („Krähenfüße“).

**2. Bedeutung**  
- positive Emotion, soziale Annäherung  
- „soziales Lächeln“ kann ohne Augenbeteiligung auftreten (nicht zwingend echte Freude)

**3. Varianten**  
[in Arbeit]

**4. Hintergrund**  
Die Aktivierung der Augenringmuskulatur unterscheidet echte (Duchenne-)Freude von aufgesetztem Lächeln.

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]

**6. Gegenläufige Verhaltensweisen**  
[in Arbeit]

**7. Beispiele**  
[in Arbeit]

**8. Sonstiges**  
Bei Chase Hughes CHEM: Happiness, Ha, 13

**9. Literatur**  
- CHEM2017 S. 31
