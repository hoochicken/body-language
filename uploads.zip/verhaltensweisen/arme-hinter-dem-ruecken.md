## Arme hinter dem Rücken  

**1. Definition / Beschreibung**  
Die Arme werden hinter dem Rücken verschränkt oder am Handgelenk gefasst.  

**2. Bedeutung**  
- Hände ineinandergelegt → Zuversicht, Überlegenheit  
- Hand hält Handgelenk → Zurückhaltung, unterdrückte Wut  

**3. Varianten**  
- ineinandergelegte Hände  
- eine Hand umfasst das andere Handgelenk  

**4. Hintergrund**  
Der Griff zeigt die Intensität der Zurückhaltung an.  

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]  

**6. Gegenläufige Verhaltensweisen**  
[in Arbeit]  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Arms Behind Back, Bb, 51  

**9. Literatur**  
- CHEM2017 S. 45  
