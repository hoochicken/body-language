## Innengewandte Zehen  

**1. Definition / Beschreibung**  
Zehen/Füße drehen nach innen; leichte Häufung bei Frauen.  

**2. Bedeutung**  
- Befangenheit, Unsicherheit  
- Wunsch, „weniger Raum“ einzunehmen  
- Schutz/Abschirmung des Genitalbereichs  

**3. Varianten**  
[in Arbeit]  

**4. Hintergrund**  
In Kombination mit Barriereverhalten ein Hinweis auf Zurückhalten/Verschleierung; Reaktion auf bedrohliche soziale Szenarien möglich.  

**5. Verstärkende Verhaltensweisen**  
- Beinenge  
- Torso abgewandt  

**6. Gegenläufige Verhaltensweisen**  
- parallele, geöffnete Fußstellung  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Inward Toe Pointing, Ip, 88  

**9. Literatur**  
- CHEM2017 S. 56  
