
## Fragen-Rückwurf  

**1. Definition / Beschreibung**  
Antwort auf eine Frage durch Gegenfragen, die Interviewer/Motive angreifen.

**2. Bedeutung**  
- Aggression/Abwehr  
- Ausweichen, Kontrolle zurückerlangen

**3. Varianten**  
[in Arbeit]

**4. Hintergrund**  
Spezialfall der Kein-Antwort-Strategie; dient der Themenverschiebung.

**5. Verstärkende Verhaltensweisen**  
- steigende Tonhöhe/Sprechtempo  
- dominante Gestik

**6. Gegenläufige Verhaltensweisen**  
- direkte Antwort ohne Gegenfrage

**7. Beispiele**  
[in Arbeit]

**8. Sonstiges**  
Bei Chase Hughes CHEM: Question Reversal, Qr, 116

**9. Literatur**  
- CHEM2017 S. 64
