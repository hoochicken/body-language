## Hände am Nacken  

**1. Definition / Beschreibung**  
Eine oder beide Hände greifen/berühren Nacken/Hinterkopf.

**2. Bedeutung**  
- Stress, Angst  
- intensives Nachdenken  
- Unsicherheit

**3. Varianten**  
[in Arbeit]

**4. Hintergrund**  
Selbstberührung im Nackenbereich dient Beruhigung; häufiges Signal bei kognitiver Last oder Bedrohungswahrnehmung.

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]

**6. Gegenläufige Verhaltensweisen**  
- Hände weg vom Kopf/Nacken  
- offene Gestik vor dem Körper

**7. Beispiele**  
[in Arbeit]

**8. Sonstiges**  
Bei Chase Hughes CHEM: Hands on Back of Neck, Bon, 67

**9. Literatur**  
- CHEM2017 S. 50  
- JNML2013 S. 55  
- JNML2013 S. 173
