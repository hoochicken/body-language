## Arme in der Luft  

**1. Definition / Beschreibung**  
Die Arme werden sichtbar hochgehoben (z. B. beim Jubeln).  

**2. Bedeutung**  
- Bequemlichkeit und Freude  
- Aufregung  
- Entspannung in sozialen Situationen  

**3. Varianten**  
[in Arbeit]  

**4. Hintergrund**  
Das Zeigen der Unterarme signalisiert Offenheit. Die Bewegung ist flüssig und ungezwungen, wenn sie echt ist.  

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]  

**6. Gegenläufige Verhaltensweisen**  
- Arme am Körper fixiert  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Arms in Air, In, 57  

**9. Literatur**  
- CHEM2017 S. 47  
