## Atmen-Bereich  

**1. Definition / Beschreibung**  
Beobachtung, wo die Atmung stattfindet (Bauch oder Brust).  

**2. Bedeutung**  
- Bauchatmung: Ruhe, Entspannung  
- Brustatmung mit hochgezogenen Schultern und offenem Mund: Stress, erhöhter Sauerstoffbedarf  

**3. Varianten**  
[noch in Arbeit]  

**4. Hintergrund**  
Die Atemlage ist ein physiologischer Indikator für Erregungsniveau und emotionale Belastung.  

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]  

**6. Gegenläufige Verhaltensweisen**  
- gleichmäßige, ruhige Nasenatmung  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Behavior Panel: Atmen-Bereich  

**9. Literatur**  
- JNML2013 S. 119  
