## Schmuckspiel  

**1. Definition / Beschreibung**  
Spielen, Zupfen, Reiben an Schmuck (Kette, Ring, Armreif, Ohrring).

**2. Bedeutung**  
- Selbstberuhigung bei Stress/Angst  
- Identitäts-/Selbstbild-bezogene Berührung

**3. Varianten**  
[in Arbeit]

**4. Hintergrund**  
Häufig bei Frauen beobachtet; taktile Reize reduzieren Erregung und schaffen Kontrolle.

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]

**6. Gegenläufige Verhaltensweisen**  
- ruhige Hände, kein Schmuckkontakt

**7. Beispiele**  
[in Arbeit]

**8. Sonstiges**  
Bei Chase Hughes CHEM: Jewelry Play, Jp, 106

**9. Literatur**  
- CHEM2017 S. 61
