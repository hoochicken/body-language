## Augenschliessdauer  

**1. Definition / Beschreibung**  
Dauer des Lidschlusses beim Blinzeln.  

**2. Bedeutung**  
- langsames Schließen: Wunsch, etwas nicht sehen zu wollen  
- zusammengekniffene Augen: Versuch, eine unangenehme Nachricht auszublenden  

**3. Varianten**  
- normales, kurzes Blinzeln  
- verlängertes Blinzeln  
- Augen zusammenkneifen  

**4. Hintergrund**  
Veränderungen in der Blinkdauer können emotionale Reaktionen oder Vermeidungshaltungen anzeigen.  

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]  

**6. Gegenläufige Verhaltensweisen**  
- normaler, gleichmäßiger Lidschlag  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Behavior Panel: Augenschliessdauer  

**9. Literatur**  
- JNML2013 S. 191  
