## Knieumarmung  

**1. Definition / Beschreibung**  
Im Sitzen werden die (angewinkelten) Beine/Knie mit beiden Armen eng an die Brust gezogen und „umarmt“.  

**2. Bedeutung**  
- starkes Bedürfnis nach Trost/Selbstberuhigung  
- Stress- und Angstreduktion  
- Rückzug, Befangenheit  

**3. Varianten**  
[in Arbeit]  

**4. Hintergrund**  
Seltene Sitzhaltung in Interviews; gilt als Adapter (beruhigende Geste), die in Abwesenheit realer Nähe symbolisch „Halt“ gibt.  

**5. Verstärkende Verhaltensweisen**  
- gesenkter Kopf, geschlossener Oberkörper  
- Barrieregesten (Objekt vor dem Körper)  

**6. Gegenläufige Verhaltensweisen**  
- offenes, entspanntes Sitzen mit Abstand zwischen Oberkörper und Oberschenkeln  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Knee Hugging, Kh, 81  

**9. Literatur**  
- CHEM2017 S. 54  
