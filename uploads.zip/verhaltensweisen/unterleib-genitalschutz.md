## Genitalschutz  

**1. Definition / Beschreibung**  
Unbewusstes Bedecken/Schützen des Genitalbereichs (v. a. im Stehen).

**2. Bedeutung**  
- unmittelbares Schutzbedürfnis  
- Verletzlichkeit, Unsicherheit  
- Reaktion auf verbale/physische/psychische Bedrohung

**3. Varianten**  
[in Arbeit]

**4. Hintergrund**  
Ein archetypischer Schutzreflex, besonders bei sozialem Druck (z. B. öffentliche Auftritte). Ein salopper Name hierfür ist auch "das Feigenblatt machen".

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]

**6. Gegenläufige Verhaltensweisen**  
- offener, entspannter Stand ohne Schutzgesten

**7. Beispiele**  
[in Arbeit]

**8. Sonstiges**  
Bei Chase Hughes CHEM: Genital Protection, Gpr, 73

**9. Literatur**  
- CHEM2017 S. 52
