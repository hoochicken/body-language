## Erhöhte Sprechgeschwindigkeit  

**1. Definition / Beschreibung**  
Temposteigerung der Sprache relativ zur Gesprächs-Baseline.

**2. Bedeutung**  
- „Es hinter sich bringen wollen“  
- Stressabbau durch Beschleunigung  
- Sichtbarmachung geringerer nonverbaler Lecks (Täuschungsmanagement)

**3. Varianten**  
[in Arbeit]

**4. Hintergrund**  
Erfordert vorherige Baseline-Erhebung (Kadenz/Tempo).

**5. Verstärkende Verhaltensweisen**  
- steigende Tonhöhe  
- flache Atmung

**6. Gegenläufige Verhaltensweisen**  
- gleichmäßiges, ruhiges Sprechtempo

**7. Beispiele**  
[in Arbeit]

**8. Sonstiges**  
Bei Chase Hughes CHEM: Increase in Vocal Speed, Spd, 111

**9. Literatur**  
- CHEM2017 S. 62
