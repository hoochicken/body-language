## Schönheitspflege  

**1. Definition / Beschreibung**  
Selbstpflege-Handlungen zur Verbesserung des Erscheinungsbildes (Haare richten, Staub abwischen, Kleidung glätten etc.).  

**2. Bedeutung**  
- Stress-/Angstregulation (häufigere Pflege bei Erziehung zu „gepflegtem Auftreten“)  
- Selbstberuhigung und soziale Anpassung  

**3. Varianten**  
[in Arbeit]  

**4. Hintergrund**  
Kontext und Auslöser (Stimulus) sind entscheidend; unter Anspannung treten Grooming-Gesten oft als „legitime“ Selbstberührung auf.  

**5. Verstärkende Verhaltensweisen**  
- Entfusseln  
- Lippenbefeuchten, Haare aus dem Gesicht streichen  

**6. Gegenläufige Verhaltensweisen**  
- ruhige, unbewegte Hände, keine Korrekturen  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Grooming Gestures, Gm, 85  

**9. Literatur**  
- CHEM2017 S. 55  
