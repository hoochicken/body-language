## Kopfschütteln  

**1. Definition / Beschreibung**  
Horizontale Kopfbewegung, meist als Verneinung verstanden.  

**2. Bedeutung**  
- Verneinung („Nein“)  
- Widerspruch zwischen verbaler Aussage und nonverbaler Geste (zeigt wahre Haltung)  
- Unglaube oder Ausdruck von Verlust  

**3. Varianten**  
[in Arbeit]  

**4. Hintergrund**  
Obwohl meist klar als „Nein“ verstanden, können Kontext und Timing zu abweichenden Interpretationen führen.  

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]  

**6. Gegenläufige Verhaltensweisen**  
- vertikales Nicken („Ja“)  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Horizontal Head Shake, No, 45  

**9. Literatur**  
- CHEM2017 S. 43  
