## Einseitiges Schulterzucken  

**1. Definition / Beschreibung**  
Nur eine Schulter wird kurz gehoben.  

**2. Bedeutung**  
- Zweifel  
- Unglauben  

**3. Varianten**  
[in Arbeit]  

**4. Hintergrund**  
Allein nicht ausreichend für Täuschung, aber in Kombination mit verbaler Aussage oder anderen Täuschungsgesten ein starker Marker.  

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]  

**6. Gegenläufige Verhaltensweisen**  
- beidseitiges Schulterzucken (Unsicherheit, Ergebung)  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Single Shoulder Shrug, Ss, 38  

**9. Literatur**  
- CHEM2017 S. 40  
- JNML2013 S. 119f  
