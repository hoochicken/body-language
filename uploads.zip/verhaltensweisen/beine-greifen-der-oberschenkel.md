## Greifen der Oberschenkel  

**1. Definition / Beschreibung**  
Eine oder beide Hände greifen/umfassen die eigenen Oberschenkel.  

**2. Bedeutung**  
- physische Anziehung/sexuelle Erregung (v. a. bei Frauen beobachtet)  
- Selbstberuhigung und Selbstkontrolle  
- Spannungsaufbau zur Hemmung des Sprechens (Informationszurückhaltung)  

**3. Varianten**  
[in Arbeit]  

**4. Hintergrund**  
Häufig verdeckt (unter dem Tisch). Schweißnasse Handflächen weisen zusätzlich auf Nervosität hin.  

**5. Verstärkende Verhaltensweisen**  
- zusammengepresste Knie  
- Blickabwendung, kurzes Einfrieren  

**6. Gegenläufige Verhaltensweisen**  
- offene Hände auf dem Tisch/Oberschenkeln, ohne Druck  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Clasping the Thighs, Thc, 86  

**9. Literatur**  
- CHEM2017 S. 55  
- JNML2013 S. 61f  
