## Kniegreifen  

**1. Definition / Beschreibung**  
Im Sitzen greifen eine oder beide Hände an (oder auf) die eigenen Knie.  

**2. Bedeutung**  
- nonverbale Vorbereitung zum Aufstehen/Beenden des Gesprächs  
- Wunsch, die Situation zu verlassen  

**3. Varianten**  
[in Arbeit]  

**4. Hintergrund**  
Häufig begleitet von tiefem Atemzug und Vorverlagerung des Oberkörpers.  

**5. Verstärkende Verhaltensweisen**  
- Blick zur Tür/aus dem Raum  
- Sitzverlagerung an die Stuhlkante  

**6. Gegenläufige Verhaltensweisen**  
- entspanntes Zurücklehnen, Hände frei  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Knee Clasp, Kc, 90  

**9. Literatur**  
- CHEM2017 S. 56  
- JNML2013 S. 76  
