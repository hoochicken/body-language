## Berühren der Brust  

**1. Definition / Beschreibung**  
Die eigene Brust wird mit der Hand berührt/abgetastet.

**2. Bedeutung**  
- Unsicherheit, Nervosität  
- Reaktion auf stressige/ängstigende Information  
- adaptives (selbstberuhigendes) Verhalten

**3. Varianten**  
[in Arbeit]

**4. Hintergrund**  
Selbstberührungen („Adapter“) dienen der Spannungsreduktion und treten in emotional belastenden Kontexten auf.

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]

**6. Gegenläufige Verhaltensweisen**  
- ruhige Hände abseits des Oberkörpers

**7. Beispiele**  
[in Arbeit]

**8. Sonstiges**  
Bei Chase Hughes CHEM: Chest Touching, Tch, 62

**9. Literatur**  
- CHEM2017 S. 49  
- JNML2013 S. 55
