## Kein-Antwort-Aussage  

**1. Definition / Beschreibung**  
Lange Antwort, die die gestellte Frage nicht beantwortet.

**2. Bedeutung**  
- Ausweichen/Manipulation  
- Thema umlenken, Zeit gewinnen

**3. Varianten**  
[in Arbeit]

**4. Hintergrund**  
Wirksamste Gegenmaßnahme: Frage wortgleich wiederholen („Schallplatte“).

**5. Verstärkende Verhaltensweisen**  
- Frage-Rückwurf  
- Ambiguität in Aussagen

**6. Gegenläufige Verhaltensweisen**  
- präzise, kurze Antwort auf die Frage

**7. Beispiele**  
[in Arbeit]

**8. Sonstiges**  
Bei Chase Hughes CHEM: Nonanswer statement, NA, 112

**9. Literatur**  
- CHEM2017 S. 62
