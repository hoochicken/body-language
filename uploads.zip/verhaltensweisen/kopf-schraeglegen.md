## Kopf-Schräglegen

**1. Definition / Beschreibung**  
Das Schräglegen des Kopfes ist eine offene Geste, die Verletzlichkeit ausdrückt.

**2. Bedeutung**  
- signalisiert Freundlichkeit  
- zeigt Neugier  
- kann Unschuld vermitteln  
- wird häufig im Flirt eingesetzt

**3. Varianten**  
[in Arbeit]

**4. Hintergrund**  
Das Schräglegen entblößt Hals/Nacken, was zugleich verletzlich und zugewandt wirkt.

**5. Verstärkende Verhaltensweisen**  
- Squinting (Augen zusammenkneifen)  
- Ja-Nicken  
- nach innen gerichtete Zehen (Inward Pointing Toes)  
- Palm Exposure (Handflächen zeigen)

**6. Gegenläufige Verhaltensweisen**  
- Jaw Clenching (Aggression/Wut)  
- Tapping (Ungeduld)

**7. Beispiele**  
[in Arbeit]

**8. Sonstiges**  
Bei Chase Hughes CHEM: Head Tilt, Ht, 1

**9. Literatur**  
- CHEM2017 S. 26  
- CHEM2017 S. 29  
- JNML2013 S. 185
