## Rumpfzuwendung  

**1. Definition / Beschreibung**  
Der Torso richtet sich einem Gegenüber zu oder von ihm weg.

**2. Bedeutung**  
- zugewandt: Interesse, Engagement  
- abgewandt: Distanzierung/Abwehr

**3. Varianten**  
- Torso zum Interviewenden  
- Torso weg vom Interviewenden

**4. Hintergrund**  
Zuwendung kann im Verlauf einer Fragegruppe wechseln (Abwehr → Zuwendung beim Antworten).

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]

**6. Gegenläufige Verhaltensweisen**  
- Hüfte/Füße abgewandt bei frontalem Oberkörper (inkongruent)

**7. Beispiele**  
[in Arbeit]

**8. Sonstiges**  
Bei Chase Hughes CHEM: Torso Facing, Fc, 79

**9. Literatur**  
- CHEM2017 S. 53  
- JNML2013 S. 92
