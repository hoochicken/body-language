## Wut  

**1. Definition / Beschreibung**  
Universaler Ausdruck: nach unten gezogene Brauen, gespannte Lippen.  

**2. Bedeutung**  
- Aggression  
- Frustration  
- kann ehrlicher Protest oder Ablenkungsversuch sein  

**3. Varianten**  
[in Arbeit]  

**4. Hintergrund**  
Wut kann in Vernehmungen sowohl bei Unschuldigen (als Abwehr) als auch bei Schuldigen (als Ablenkung von Beweisen) auftreten.  

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]  

**6. Gegenläufige Verhaltensweisen**  
- Palm Exposure (Handflächen zeigen)  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Anger, Ag, 34  

**9. Literatur**  
- CHEM2017 S. 40  
