## Panik-Kobra  

**1. Definition / Beschreibung**  
Beide Hände liegen auf dem Kopf, die Finger sind verschränkt.  

**2. Bedeutung**  
- Ausdruck von Panik  
- Hilflosigkeit  

**3. Varianten**  
[noch in Arbeit]  

**4. Hintergrund**  
Diese Geste ist selten und tritt in extremen Stresssituationen auf, z. B. bei der Konfrontation mit erdrückenden Beweisen.  

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]  

**6. Gegenläufige Verhaltensweisen**  
- offene, entspannte Körperhaltung  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Behavior Panel: Panik-Kobra  

**9. Literatur**  
- JNML2013 S. 57  
