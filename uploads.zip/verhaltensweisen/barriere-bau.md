## Barrierenbau  

**1. Definition / Beschreibung**  
Ein Arm/Objekt wird (unbewusst) zwischen sich und den Gesprächspartner gebracht.

**2. Bedeutung**  
- Bedürfnis nach Schutz/Sicherheit  
- situatives Bedrohungsgefühl  
- Distanz schaffen

**3. Varianten**  
[in Arbeit]

**4. Hintergrund**  
Subtile, oft kurzzeitig auftretende Schutzgeste in belastenden sozialen Situationen.

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]

**6. Gegenläufige Verhaltensweisen**  
- offene Körperhaltung ohne Zwischenobjekte

**7. Beispiele**  
[in Arbeit]

**8. Sonstiges**  
Bei Chase Hughes CHEM: Barriergestures, Bc, 70

**9. Literatur**  
- CHEM2017 S. 51
