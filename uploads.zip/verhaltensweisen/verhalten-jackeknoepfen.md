## Jackeknöpfen  

**1. Definition / Beschreibung**  
Jacke/Blazer wird (plötzlich) zugeknöpft; häufiger bei Männerkleidung.  

**2. Bedeutung**  
- Vertrauenseinbruch  
- Zurückhaltung/Angst  
- Temperatur kann Verhalten beeinflussen  

**3. Varianten**  
[in Arbeit]  

**4. Hintergrund**  
„Schließen“ verstärkt Barrierewirkung des Kleidungsstücks und markiert inneren Rückzug.  

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]  

**6. Gegenläufige Verhaltensweisen**  
- Jacke offen, lockere Haltung  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Jacket Buttoning, Jb, 98  

**9. Literatur**  
- CHEM2017 S. 59  
