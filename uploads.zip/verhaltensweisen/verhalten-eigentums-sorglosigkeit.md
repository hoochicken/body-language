## Eigentums-Sorglosigkeit  

**1. Definition / Beschreibung**  
Sorgloser, achtloser Umgang mit eigenen Gegenständen (werfen, fallen lassen, grob hinlegen).  

**2. Bedeutung**  
- distanzierte, sorglose Haltung  
- geringe Kooperationsbereitschaft; trägt die Vernehmung nicht voran  

**3. Varianten**  
[in Arbeit]  

**4. Hintergrund**  
Manifestationen: Portemonnaie werfen, Stuhl grob ziehen, Jacke/Telefon/Schlüssel achtlos ablegen.  

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]  

**6. Gegenläufige Verhaltensweisen**  
- ordentlicher, respektvoller Umgang mit Eigentum  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Belonging Carelessness, Bc, 96  

**9. Literatur**  
- CHEM2017 S. 58  
