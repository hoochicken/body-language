## Wortverstärker  

**1. Definition / Beschreibung**  
Rhythmische Handbewegungen, die Silben oder Worte im Sprechrhythmus betonen.  

**2. Bedeutung**  
- verstärken und strukturieren Sprache  
- vermitteln Nachdruck und Klarheit  
- asynchrone Bewegungen können auf Diskrepanz zwischen Gesagtem und Gefühl hindeuten  

**3. Varianten**  
[in Arbeit]  

**4. Hintergrund**  
Synchronität zwischen Sprache und Gestik unterstützt Authentizität. Zeitlicher Versatz deutet oft auf Stress, Unsicherheit oder Täuschung hin.  

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]  

**6. Gegenläufige Verhaltensweisen**  
- Finger-Spreizen (zeigt eher Stress/Angst/Negativität an)  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Baton Gestures, Bg, 22  

**9. Literatur**  
- CHEM2017 S. 35  
