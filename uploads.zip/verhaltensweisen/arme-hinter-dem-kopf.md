## Arme hinter dem Kopf (Kobra)  

**1. Definition / Beschreibung**  
Die Hände werden hinter dem Kopf verschränkt.  

**2. Bedeutung**  
- demonstrierte Zuversicht (oft gespielt)  
- Dominanzsignal  
- Verachtung, Unsicherheit  

**3. Varianten**  
[in Arbeit]  

**4. Hintergrund**  
Die Pose wirkt nach außen überlegen, ist aber häufig Ausdruck innerer Unsicherheit oder Dominanztheater.  

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]  

**6. Gegenläufige Verhaltensweisen**  
- offene, entspannte Handhaltung vor dem Körper  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Behind Head, Bh, 48  

**9. Literatur**  
- CHEM2017 S. 44  
- JNML2013 S. 138  
