## Hand zur Stirn  

**1. Definition / Beschreibung**  
Die Person führt ihre Hand oder die Fingerspitzen zur Stirn.  

**2. Bedeutung**  
- Hinweis auf Unbehagen  
- Ausdruck innerer Anspannung  

**3. Varianten**  
[noch in Arbeit]  

**4. Hintergrund**  
Selbstberührung im Gesichtsbereich gilt oft als Indikator für Stressregulation oder als Zeichen innerer Belastung.  

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]  

**6. Gegenläufige Verhaltensweisen**  
[in Arbeit]  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei JNML2013: Hand zur Stirn  

**9. Literatur**  
- JNML2013 S. 55  
