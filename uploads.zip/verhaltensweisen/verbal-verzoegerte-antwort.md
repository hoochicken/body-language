## Stimmliches Zögern  

**1. Definition / Beschreibung**  
Wahrnehmbare Pause, bevor eine Antwort gegeben wird.

**2. Bedeutung**  
- Zeitgewinn, um Erzählung mental zu prüfen/konstruieren  
- potentielle Inkongruenz zwischen Wissen und Aussage

**3. Varianten**  
[in Arbeit]

**4. Hintergrund**  
Relevanz nur bei klarer, timingbezogener Kopplung an die Frage; Baseline beachten.

**5. Verstärkende Verhaltensweisen**  
- Fülllaute („äh“, „hm“)  
- Blickabwendung

**6. Gegenläufige Verhaltensweisen**  
- unmittelbare, flüssige Antwort

**7. Beispiele**  
[in Arbeit]

**8. Sonstiges**  
Bei Chase Hughes CHEM: Vocal Hesitancy, Hes, 108

**9. Literatur**  
- CHEM2017 S. 61
