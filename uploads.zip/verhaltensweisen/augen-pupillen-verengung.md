## Pupillen-Verengung  

**1. Definition / Beschreibung**  
Verkleinerung der Pupillengröße durch äußere oder emotionale Reize.  

**2. Bedeutung**  
- Aversion gegen gesehene oder gehörte Inhalte  
- physiologische Anpassung an Licht  
- individuell unterschiedlich stark ausgeprägt  

**3. Varianten**  
[in Arbeit]  

**4. Hintergrund**  
Pupillenverengung kann durch Licht oder Emotion entstehen. Bei hellen Augen leichter sichtbar, bei dunklen Augen schwieriger zu erkennen. Augenfarbe sollte bei der Beobachtung notiert werden.  

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]  

**6. Gegenläufige Verhaltensweisen**  
- Pupillenerweiterung (positive Reize)  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Pupil Constriction, Pc, 42  

**9. Literatur**  
- CHEM2017 S. 42  
