## Stuhlbeine-Umwinden  

**1. Definition / Beschreibung**  
Die Knöchel/Füße umklammern die Stuhlbeine, als ob man sich „festhält“.

**2. Bedeutung**  
- Selbstregulation  
- Zurückhaltung, geringe Gesprächsbereitschaft

**3. Varianten**  
[in Arbeit]

**4. Hintergrund**  
Besonders bei jüngeren Erwachsenen in Vernehmungen beobachtet; Indiz für inneren Widerstand.

**5. Verstärkende Verhaltensweisen**  
- Fußrückzieher  
- Beinenge

**6. Gegenläufige Verhaltensweisen**  
- Füße locker aufgestellt

**7. Beispiele**  
[in Arbeit]

**8. Sonstiges**  
Bei Chase Hughes CHEM: Feet around Chair Legs, Cl, 107

**9. Literatur**  
- CHEM2017 S. 61  
- JNML2013 S. 97
