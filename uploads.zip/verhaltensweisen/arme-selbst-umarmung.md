## Selbst-Umarmung  

**1. Definition / Beschreibung**  
Beide Arme umschlingen aktiv den eigenen Körper.  

**2. Bedeutung**  
- Trost und Selbstberuhigung (Daumen nicht nach oben)  
- Selbstvertrauen und Entspannung (Daumen nach oben)  

**3. Varianten**  
- Daumen nach unten → Unsicherheit, Trostbedürfnis  
- Daumen nach oben → Selbstvertrauen  

**4. Hintergrund**  
Eine geschlossene Geste, häufiger bei Frauen.  

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]  

**6. Gegenläufige Verhaltensweisen**  
[in Arbeit]  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Self-Hug, Shg, 50  

**9. Literatur**  
- CHEM2017 S. 45  
- JNML2013 S. 64  
- JNML2013 S. 131  
