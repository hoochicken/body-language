## Entfusseln  

**1. Definition / Beschreibung**  
(Vermeintliches) Entfernen von Flusen/Staub von Kleidung oder nahen Objekten.

**2. Bedeutung**  
- nervöse Energie  
- Unsicherheit  
- Gesprächsvermeidung

**3. Varianten**  
[in Arbeit]

**4. Hintergrund**  
Ein typischer „Beschäftiger“, um unangenehme Momente zu überbrücken oder Sprechen hinauszuzögern.

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]

**6. Gegenläufige Verhaltensweisen**  
- ungestörte Aufmerksamkeit auf Gesprächspartner

**7. Beispiele**  
[in Arbeit]

**8. Sonstiges**  
Bei Chase Hughes CHEM: Lint Picking, Lp, 68

**9. Literatur**  
- CHEM2017 S. 50  
- JNML2013 S. 155f
