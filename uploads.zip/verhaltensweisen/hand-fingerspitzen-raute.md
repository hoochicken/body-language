## Fingerspitzen-Raute  

**1. Definition / Beschreibung**  
Die Fingerspitzen beider Hände berühren sich und bilden eine Dach-/Rauteform.  

**2. Bedeutung**  
- Selbstvertrauen  
- Kontrollgefühl  

**3. Varianten**  
- auf Kopfhöhe  
- auf Brusthöhe  
- auf Hüft-/Tischhöhe  

**4. Hintergrund**  
Je höher die Geste ausgeführt wird, desto selbstsicherer und aufnahmebereiter wirkt die Person.  

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]  

**6. Gegenläufige Verhaltensweisen**  
[in Arbeit]  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Steepling, St, 47  

**9. Literatur**  
- CHEM2017 S. 44  
- JNML2013 S. 161  
