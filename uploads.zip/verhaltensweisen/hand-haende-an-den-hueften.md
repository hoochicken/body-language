## Hände an den Hüften  

**1. Definition / Beschreibung**  
Beide Hände ruhen mit Daumen oder Fingern an der Hüfte.  

**2. Bedeutung**  
- Männer, Daumen nach hinten: Dominanz, Tonangebend  
- Frauen, Daumen nach vorne: Attraktivität zeigen oder Neugier  

**3. Varianten**  
- Daumen nach hinten  
- Daumen nach vorne  

**4. Hintergrund**  
Die gleiche Geste kann geschlechts- und kontextabhängig unterschiedliche Bedeutungen haben.  

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]  

**6. Gegenläufige Verhaltensweisen**  
- Arme locker an den Seiten  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Arms on hip, Ah, 49  

**9. Literatur**  
- CHEM2017 S. 44  
- JNML2013 S. 135f  
