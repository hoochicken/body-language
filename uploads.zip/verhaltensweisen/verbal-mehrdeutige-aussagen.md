## Mehrdeutige Aussagen  

**1. Definition / Beschreibung**  
Vage, unpräzise Antworten zu relevanten Ereignissen/Zeiten/Orten.

**2. Bedeutung**  
- Unsicherheit, Ausweichen  
- potenzielle Verschleierung

**3. Varianten**  
[in Arbeit]

**4. Hintergrund**  
„Ich erinnere mich nicht genau“/„Normalerweise…“ sind typische Muster; Detailarmut ist hier das Signal.

**5. Verstärkende Verhaltensweisen**  
- stimmliches Zögern  
- Pronomen-Mangel

**6. Gegenläufige Verhaltensweisen**  
- konkrete Zeit-/Ortsangaben

**7. Beispiele**  
[in Arbeit]

**8. Sonstiges**  
Bei Chase Hughes CHEM: Ambiguity Statements, Amm, 117

**9. Literatur**  
- CHEM2017 S. 64
