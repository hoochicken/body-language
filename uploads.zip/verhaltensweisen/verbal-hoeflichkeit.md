## Höflichkeit  

**1. Definition / Beschreibung**  
Plötzlicher Wechsel zu überhöht formeller Anrede/Etikette im Gespräch.

**2. Bedeutung**  
- Verschleierung, „Glattpolieren“ der Aussage  
- Distanz/Statusspiel

**3. Varianten**  
[in Arbeit]

**4. Hintergrund**  
Relevanter ist die Änderung des Höflichkeitsniveaus, nicht Höflichkeit an sich (kultur- und sprachabhängig).

**5. Verstärkende Verhaltensweisen**  
- Lebenswandel-Ausrede  
- Kein-Antwort-Aussagen

**6. Gegenläufige Verhaltensweisen**  
- konstantes, natürliches Höflichkeitsniveau

**7. Beispiele**  
[in Arbeit]

**8. Sonstiges**  
Bei Chase Hughes CHEM: Politeness, Pol, 118

**9. Literatur**  
- CHEM2017 S. 64
