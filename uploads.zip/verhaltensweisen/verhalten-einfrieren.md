## Einfrieren  

**1. Definition / Beschreibung**  
Plötzlicher Bewegungsstopp oder deutliche Verlangsamung.  

**2. Bedeutung**  
- Teil der „Fight-Flight-Freeze“-Reaktion  
- Täuschungsmarker (kognitive Überlastung)  
- Schutzstrategie bei Bedrohung  

**3. Varianten**  
[in Arbeit]  

**4. Hintergrund**  
Das retikuläre System priorisiert Sicherheit und blockiert Bewegung. Häufig bei Missbrauchsopfern beobachtet, die Aufmerksamkeit vermeiden wollen.  

**5. Verstärkende Verhaltensweisen**  
- Angstgesicht  
- angespannte Muskulatur  

**6. Gegenläufige Verhaltensweisen**  
- natürliche, fließende Bewegungen  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Freeze, Fz, 54  

**9. Literatur**  
- CHEM2017 S. 46  
- JNML2013 S. 126f  
