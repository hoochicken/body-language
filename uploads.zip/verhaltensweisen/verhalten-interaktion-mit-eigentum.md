## Interaktion mit Eigentum  

**1. Definition / Beschreibung**  
Art und Weise, wie eine Person ihre Umgebung (Möbel, Objekte) anfasst/verändert.  

**2. Bedeutung**  
- Anpassung/Umgestalten → Komfort, Handlungsbereitschaft  
- übervorsichtiger, „steriler“ Umgang → Stress, Täuschungsmanagement möglich (kontextabhängig)  

**3. Varianten**  
[in Arbeit]  

**4. Hintergrund**  
Schuldige/Unschuldige haben unterschiedliche Baselines von Behagen; daher Kontext- und Personvergleich nötig.  

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]  

**6. Gegenläufige Verhaltensweisen**  
- starre Körperhaltung, keine Umweltinteraktion  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Object Interactions, Oi, 94  

**9. Literatur**  
- CHEM2017 S. 58  
