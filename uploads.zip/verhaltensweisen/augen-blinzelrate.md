## Blinzelrate  

**1. Definition / Beschreibung**  
Die Anzahl der Lidschläge pro Minute.  

**2. Bedeutung**  
- niedrige Blinkrate: hohe Konzentration, Fokussierung  
- erhöhte Blinkrate: Stress, Aufregung, Verachtung  
- im Flirt: erhöhte Blinkrate möglich  

**3. Varianten**  
[in Arbeit]  

**4. Hintergrund**  
Blinkrate variiert je nach Emotion, Stresslevel oder Aufmerksamkeit. Schnelles Blinzeln kann Dominanz oder Überlegenheit anzeigen.  

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]  

**6. Gegenläufige Verhaltensweisen**  
- stabile, gleichmäßige Blinkrate  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Ex Blink Rate, Br, 26  

**9. Literatur**  
- CHEM2017 S. 36  
