## Überraschung  

**1. Definition / Beschreibung**  
Universaler Gesichtsausdruck mit gehobenen Augenbrauen, geweiteten Augen und geöffnetem Mund.  

**2. Bedeutung**  
- plötzliches Erkennen oder Wahrnehmen von Unerwartetem  
- unterdrückte Überraschung zeigt sich oft noch durch ein leichtes Absinken des Unterkiefers  

**3. Varianten**  
[in Arbeit]  

**4. Hintergrund**  
Überraschung gehört zu den 7 universellen Gesichtsausdrücken. Training kann sie reduzieren, vollständiges Unterdrücken ist jedoch schwer.  

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]  

**6. Gegenläufige Verhaltensweisen**  
- kontrollierte Mimik ohne plötzliche Veränderung  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Surprise, Sp, 25  

**9. Literatur**  
- CHEM2017 S. 36  
