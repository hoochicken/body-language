## Augenbrauenblitz

**1. Definition / Beschreibung**  
Kurzes Anheben und Senken der Augenbrauen.

**2. Bedeutung**  
- freundlicher Gruß  
- Betonung wichtiger Punkte  
- signalisiert Offenheit  
- vermittelt Vertrauenswürdigkeit/Verletzlichkeit

**3. Varianten**  
- schneller Augenbrauenblitz  
- konstant erhobene Augenbrauen (können Wut/Angst signalisieren)

**4. Hintergrund**  
Oft unbewusst und reflexhaft sozial erwidert.

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]

**6. Gegenläufige Verhaltensweisen**  
[in Arbeit]

**7. Beispiele**  
[in Arbeit]

**8. Sonstiges**  
Bei Chase Hughes CHEM: Eyebrow Flash, Ef, 3

**9. Literatur**  
- CHEM2017 S. 27  
- JNML2013 S. 194
