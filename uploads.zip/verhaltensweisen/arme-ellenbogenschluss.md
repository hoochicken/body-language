## Ellenbogenschluss  

**1. Definition / Beschreibung**  
Die Ellenbogen werden im Sitzen nach innen gezogen, meist am Tisch.  

**2. Bedeutung**  
- Schutzverhalten  
- Unsicherheit  
- Unbehagen  

**3. Varianten**  
[in Arbeit]  

**4. Hintergrund**  
Nicht-vitale Körperteile schützen vitale Bereiche. Besonders in polizeilichen Vernehmungen beobachtet. Temperatur kann das Verhalten ebenfalls begünstigen.  

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]  

**6. Gegenläufige Verhaltensweisen**  
- offene Armhaltung am Tisch  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Elbow Closure, Ec, 37  

**9. Literatur**  
- CHEM2017 S. 41  
