## Pupillenweite  

**1. Definition / Beschreibung**  
Veränderung der Pupillengröße durch Emotionen oder äußere Reize.  

**2. Bedeutung**  
- Erweiterung: positive emotionale/visuelle Reize (Attraktivität, Babys, Freude)  
- Verengung: negative Stimuli (Ekel, Abscheu, Trauma)  

**3. Varianten**  
- Pupillenerweiterung (positive Stimuli)  
- Pupillenverengung (negative Stimuli)  

**4. Hintergrund**  
Pupillenreaktionen sind physiologisch, werden jedoch auch emotional beeinflusst. Beobachtung gelingt besser unter konstanten Lichtverhältnissen.  

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]  

**6. Gegenläufige Verhaltensweisen**  
[in Arbeit]  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Pupil Dilation, Pd, 27  

**9. Literatur**  
- CHEM2017 S. 37  
