## Schildkröteln

**1. Definition / Beschreibung**  
Schultern ziehen hoch, Kopf wird eingezogen („Schildkrötenhaltung“).

**2. Bedeutung**  
- Angst/Schutzreaktion  
- Rückzug in belastenden Situationen

**3. Varianten**  
[in Arbeit]

**4. Hintergrund**  
Schützt Hals/Kehlbereich (vital); bei traumatisierten Personen häufiger beobachtbar; Kälte kann das Verhalten begünstigen.

**5. Verstärkende Verhaltensweisen**  
- Schutzgesten vor dem Oberkörper  
- zusammengezogene Körpermitte

**6. Gegenläufige Verhaltensweisen**  
- offener Brustkorb  
- gesenkte Schultern, langer Nacken

**7. Beispiele**  
[in Arbeit]

**8. Sonstiges**  
Bei Chase Hughes CHEM: Turteling, Tu, 7

**9. Literatur**  
- CHEM2017 S. 29  
- JNML2013 S. 46  
- JNML2013 S. 121
