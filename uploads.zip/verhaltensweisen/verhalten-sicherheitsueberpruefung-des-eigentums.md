## Sicherheitsüberprüfung des Eigentums  

**1. Definition / Beschreibung**  
Visuelles/physisches Prüfen von Tasche, Geldbörse, Smartphone, Tascheninhalten.

**2. Bedeutung**  
- Misstrauen, Nervosität, Unsicherheit  
- Bedürfnis nach Kontrolle/Sicherheit

**3. Varianten**  
- Handtasche näher ziehen/kurz berühren  
- nach Geldbörse/Smartphone „fühlen“  
- Taschen abklopfen

**4. Hintergrund**  
„Security Check“ tritt oft unbewusst auf, besonders in belastenden Gesprächsphasen.

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]

**6. Gegenläufige Verhaltensweisen**  
- Gegenstände offen liegen lassen, keine Prüfungen

**7. Beispiele**  
[in Arbeit]

**8. Sonstiges**  
Bei Chase Hughes CHEM: Personal Belonging Security Check, Bs, 103

**9. Literatur**  
- CHEM2017 S. 60
