## Kinnhebe

**1. Definition / Beschreibung**  
Das Anheben des Kinns ist in vielen Kulturen verbreitet; es dient als Richtungs- oder Zustimmungszeichen.

**2. Bedeutung**  
- Ausdruck von Wut, Unzufriedenheit oder Herausforderung  
- Luft-machen-Geste (Kragen lockern, Hals freilegen)

**3. Varianten**  
[in Arbeit]

**4. Hintergrund**  
Das Anheben exponiert den Hals und kann in konfrontativen Kontexten Trotz signalisieren; in Stresssituationen erleichtert es das Belüften/Kühlen.

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]

**6. Gegenläufige Verhaltensweisen**  
[in Arbeit]

**7. Beispiele**  
[in Arbeit]

**8. Sonstiges**  
Bei Chase Hughes CHEM: Chin Thrust, Ctm, 2

**9. Literatur**  
- CHEM2017 S. 26  
- JNML2013 S. 216
