## Beugen der Finger  

**1. Definition / Beschreibung**  
Die Finger werden (mikromotorisch bis deutlich) in Richtung Handfläche eingezogen.  

**2. Bedeutung**  
- Echtzeitmarker für Angst/Anspannung zur jeweiligen Frage  
- je stärker das Einziehen, desto größer die erlebte Angst  

**3. Varianten**  
[in Arbeit]  

**4. Hintergrund**  
Feinmotorische Fingerbewegungen sind in Verhören sehr aussagekräftig, besonders in Kopplung mit Inhalt/Timing einer Fragegruppe.  

**5. Verstärkende Verhaltensweisen**  
- erhöhte Atemfrequenz  
- Muskeltonus in Unterarmen/Händen  

**6. Gegenläufige Verhaltensweisen**  
- geöffnete, ruhige Finger/Hände  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Digital Fexion, Df, 82  

**9. Literatur**  
- CHEM2017 S. 54  
