## Schulterzucken  

**1. Definition / Beschreibung**  
Heben und Senken der Schultern; kann ein- oder beidseitig auftreten.  

**2. Bedeutung**  
- Unsicherheit  
- Ergebung  
- Verneinung von Schuld  
- in Vernehmungen teils mit Täuschung assoziiert  

**3. Varianten**  
- beidseitiges Schulterzucken  
- einseitiges Schulterzucken (s. auch gesondert)  

**4. Hintergrund**  
Seit Darwin erforscht. Kombinationen mit Kopfneigung, Augenbrauenblitz oder Mimik verändern die Bedeutung. Einseitiges Schulterzucken wird häufiger mit Täuschung verbunden.  

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]  

**6. Gegenläufige Verhaltensweisen**  
[in Arbeit]  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Shoulder Shrugging, Sh, 29  

**9. Literatur**  
- CHEM2017 S. 38  
- JNML2013 S. 119f  
