## Handgelenk zur Stirn  

**1. Definition / Beschreibung**  
Das Handgelenk wird an/gegen die Stirn geführt.

**2. Bedeutung**  
- Stressreduktion  
- innere Konfliktregulation  
- Selbstberuhigung

**3. Varianten**  
[in Arbeit]

**4. Hintergrund**  
Verwandt mit Ventilations-/Selbstberuhigungsgesten; taktiler Reiz dient der Spannungsreduktion.

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]

**6. Gegenläufige Verhaltensweisen**  
- Hände unten, entspannte Mimik

**7. Beispiele**  
[in Arbeit]

**8. Sonstiges**  
Bei Chase Hughes CHEM: Wrist to Forehead, Wf, 69

**9. Literatur**  
- CHEM2017 S. 50  
- JNML2013 S. 55
