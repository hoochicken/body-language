## Augenlidgerubbel  

**1. Definition / Beschreibung**  
Mit den Fingern/der Hand wird am (unteren/oberen) Augenlid gerieben.  

**2. Bedeutung**  
- Besorgnis, Stress  
- Blickkontakt vermeiden  
- Konsternation, Zweifel, Widerspruch  

**3. Varianten**  
[in Arbeit]  

**4. Hintergrund**  
„Hand-am-Gesicht“-Geste; häufiger bei Männern. Kann gedankliche Unterbrechung („Gedankenstopp“) signalisieren.  

**5. Verstärkende Verhaltensweisen**  
- Seufzen  
- Stirnrunzeln  

**6. Gegenläufige Verhaltensweisen**  
- offener, stabiler Blickkontakt  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Eyelid Rubbing, Er, 89  

**9. Literatur**  
- CHEM2017 S. 56  
- JNML2013 S. 49  
