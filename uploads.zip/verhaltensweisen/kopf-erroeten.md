## Erröten

**1. Definition / Beschreibung**  
Sichtbare Rötung des Gesichts/Halses.

**2. Bedeutung**  
- häufig Peinlichkeit, Schuld oder Angst  
- alternativ auch: Alkohol, sexuelle Erregung, bestimmte Substanzen

**3. Varianten**  
[in Arbeit]

**4. Hintergrund**  
Adrenalin führt zu Vasodilatation (Gefäßerweiterung) und sichtbarer Rötung; Kontext klärt die Ursache.

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]

**6. Gegenläufige Verhaltensweisen**  
[in Arbeit]

**7. Beispiele**  
[in Arbeit]

**8. Sonstiges**  
Bei Chase Hughes CHEM: Flushing, Fl, 14

**9. Literatur**  
- CHEM2017 S. 31  
- JNML2013 S. 212
