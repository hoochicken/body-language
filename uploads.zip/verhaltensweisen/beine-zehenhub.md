## Zehenhub  

**1. Definition / Beschreibung**  
Die Zehen werden aktiv nach oben gezogen (gegen die Schwerkraft).

**2. Bedeutung**  
- Erleichterung  
- Freude, Begeisterung  
- häufig zusammen mit „Arme in der Luft“

**3. Varianten**  
[in Arbeit]

**4. Hintergrund**  
Ein energischer, positiver Erregungsmarker; oft unbewusst.

**5. Verstärkende Verhaltensweisen**  
- Arme in der Luft  
- freudige Mimik

**6. Gegenläufige Verhaltensweisen**  
- flacher Fuß, kein aktiver Zehenhub

**7. Beispiele**  
[in Arbeit]

**8. Sonstiges**  
Bei Chase Hughes CHEM: Toes up, Agg, 77

**9. Literatur**  
- CHEM2017 S. 53  
- JNML2013 S. 79
