## Uhrgucker  

**1. Definition / Beschreibung**  
Blick/Kopf wird zur Uhr geführt; oft wird die Uhr fixiert/gedreht.  

**2. Bedeutung**  
- Zeitdruck/Desinteresse  
- Übergangshandlung, Gespräch beenden wollen  
- prüfe unübliche Muskelspannung der Gegenhand (Barriereähnlichkeit)  

**3. Varianten**  
[in Arbeit]  

**4. Hintergrund**  
Parallelen zum „Handgelenk berühren“: kann Stress-/Kontrollgeste sein.  

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]  

**6. Gegenläufige Verhaltensweisen**  
- stabiler Blickkontakt, kein Zeitfokus  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Watch Checking, Wc, 97  

**9. Literatur**  
- CHEM2017 S. 58  
