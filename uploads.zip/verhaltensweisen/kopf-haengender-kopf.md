## Hängender Kopf

**1. Definition / Beschreibung**  
Der Kopf wird gesenkt, oft mit Blick zum Boden.

**2. Bedeutung**  
- Scham/Schuld  
- Unterwerfung  
- Wut (kontextabhängig)

**3. Varianten**  
[in Arbeit]

**4. Hintergrund**  
Geste kann Schutzhaltungen (z. B. der Genitalregion) begleiten; häufiger bei Opfern von Missbrauch/Mobbing beobachtet.

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]

**6. Gegenläufige Verhaltensweisen**  
[in Arbeit]

**7. Beispiele**  
[in Arbeit]

**8. Sonstiges**  
Bei Chase Hughes CHEM: Head downcast, Hd, 4

**9. Literatur**  
- CHEM2017 S. 27
