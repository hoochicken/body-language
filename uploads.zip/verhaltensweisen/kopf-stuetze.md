## Kopfstütze  

**1. Definition / Beschreibung**  
Der Kopf ruht auf der Hand oder lehnt seitlich an ihr.  

**2. Bedeutung**  
- Langeweile  
- Müdigkeit  
- Desinteresse  

**3. Varianten**  
- Wange ruht in der Hand  
- Kopf seitlich abgelegt, auf Ohrhöhe  

**4. Hintergrund**  
Mehr Haut-zu-Haut-Kontakt weist auf stärkere Langeweile hin. Eine seitliche Ablage des Kopfes zeigt zusätzlich Halsverletzlichkeit, ähnlich wie beim Kopf-Schräglegen.  

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]  

**6. Gegenläufige Verhaltensweisen**  
- aufrechter Kopf, aktive Mimik  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Head Support, Hs, 24  

**9. Literatur**  
- CHEM2017 S. 35  
