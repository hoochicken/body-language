## Schlucken  

**1. Definition / Beschreibung**  
Sichtbare Halsbewegung durch Schlucken, oft mehrfach wiederholt.  

**2. Bedeutung**  
- Stress oder Angst  
- kann Täuschung anzeigen (kontextabhängig)  

**3. Varianten**  
[in Arbeit]  

**4. Hintergrund**  
Stress/Adrenalin steigern Speichelproduktion. Schlucken kann Stress- oder Täuschungsmarker sein, muss aber gegen Baseline und physiologische Ursachen (Durst, Medikamente) geprüft werden.  

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]  

**6. Gegenläufige Verhaltensweisen**  
[in Arbeit]  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Swallowing, Sw, 36  

**9. Literatur**  
- CHEM2017 S. 40  
