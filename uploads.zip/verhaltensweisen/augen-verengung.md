## Augenverengung  

**1. Definition / Beschreibung**  
Die Augen werden bewusst zusammengekniffen; Backenmuskeln sind aktiv beteiligt.  

**2. Bedeutung**  
- Stress  
- Ablehnung  
- Angst  
- Verwirrung oder tiefe Konzentration  

**3. Varianten**  
[in Arbeit]  

**4. Hintergrund**  
Anders als bei der Augenanspannung wird die Verengung durch aktive Beteiligung der Backenmuskulatur erzeugt. Kombination mit Kopf-Schräglegen oder Augenbrauenbewegungen gibt Aufschluss über Kontext.  

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]  

**6. Gegenläufige Verhaltensweisen**  
- weit geöffnete Augen  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Eye Squint, Sq, 28  

**9. Literatur**  
- CHEM2017 S. 37  
- JNML2013 S. 182  
- JNML2013 S. 188  
