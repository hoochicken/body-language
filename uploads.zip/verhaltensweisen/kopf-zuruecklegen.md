## Kopf-Zurücklegen

**1. Definition / Beschreibung**  
Der Kopf wird nach hinten gelehnt.

**2. Bedeutung**  
- kognitives Abrufen/Überlegen (Informationssuche)  
- exponierende Dominanz-/Trotzgeste (keine Angst zeigen)

**3. Varianten**  
[in Arbeit]

**4. Hintergrund**  
Einerseits Abrufhaltung beim Nachdenken; andererseits Exposition vitaler Bereiche (Hals) in konfrontativen Situationen.

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]

**6. Gegenläufige Verhaltensweisen**  
[in Arbeit]

**7. Beispiele**  
[in Arbeit]

**8. Sonstiges**  
Bei Chase Hughes CHEM: Head back, Hb, 15

**9. Literatur**  
- CHEM2017 S. 32
