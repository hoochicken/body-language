## Barrierenkreuz  

**1. Definition / Beschreibung**  
Beine zeigen zum Gegenüber und sind so gekreuzt, dass der Unterschenkel über dem Knie liegt („blockend“).

**2. Bedeutung**  
- Zurückhalten/Verschleiern  
- nervöse Spannung durch Situation oder Gesprächsinhalt

**3. Varianten**  
[in Arbeit]

**4. Hintergrund**  
Unterscheidet sich von „Ziffer Vier“ und klassischem Beinekreuzen; deutlich geschlossenere, „sperrende“ Beinhaltung.

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]

**6. Gegenläufige Verhaltensweisen**  
- entspanntes, klassisches Beinekreuzen  
- Beine ungekreuzt, offen

**7. Beispiele**  
[in Arbeit]

**8. Sonstiges**  
Bei Chase Hughes CHEM: Barrier Cross, Bc, 71

**9. Literatur**  
- CHEM2017 S. 51  
- JNML2013 S. 88
