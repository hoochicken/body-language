## Umgreifen der Kehle  

**1. Definition / Beschreibung**  
Die Hand umgreift den Hals oder streicht darüber.  

**2. Bedeutung**  
- Angst  
- hoher Stress  

**3. Varianten**  
[in Arbeit]  

**4. Hintergrund**  
Das Umgreifen der Kehle wirkt stark angstassoziiert. Stimuliert möglicherweise den Nervus vagus, was den Herzschlag beruhigen kann.  

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]  

**6. Gegenläufige Verhaltensweisen**  
[in Arbeit]  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Throat Clasping, Ttc, 57  

**9. Literatur**  
- CHEM2017 S. 47  
- JNML2013 S. 57  
