## Augenbrauen-Zusammenschub

**1. Definition / Beschreibung**  
Die Augenbrauen werden zur Nasenwurzel hin zusammengezogen.

**2. Bedeutung**  
- in westlichen Kulturen: häufig Wut  
- universell: hohe Konzentration/Vertiefung

**3. Varianten**  
- Zusammenziehen aus Wut  
- Zusammenziehen zur Konzentration

**4. Hintergrund**  
Dient der Fokussierung visueller Reize; in Vernehmungen kann es auf emotionale Aktivierung oder gedankliche Verarbeitung hinweisen.

**5. Verstärkende Verhaltensweisen**  
- gepresste Lippen  
- starrer Blick  
- angespannter Oberkörper

**6. Gegenläufige Verhaltensweisen**  
- entspannte Stirn  
- hochgezogene Augenbrauen (Überraschung/Interesse)

**7. Beispiele**  
[in Arbeit]

**8. Sonstiges**  
Bei Chase Hughes CHEM: Eyebrow-Narrowing, Bn, 18

**9. Literatur**  
- CHEM2017 S. 33
