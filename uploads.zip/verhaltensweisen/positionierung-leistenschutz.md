## Leistenschutz  

**1. Definition / Beschreibung**  
Unbewusstes Bedecken/abschirmen des Genitalbereichs mit Händen/Unterarmen/Objekten.

**2. Bedeutung**  
- akutes Schutzbedürfnis  
- Wahrnehmung verbaler/physischer/psychologischer Bedrohung  
- Unsicherheit, Verletzlichkeit

**3. Varianten**  
[in Arbeit]

**4. Hintergrund**  
Archetypische Barrieregeste; unterscheidet sich von Objekt-Barrieren, da der Genitalbereich direkt geschützt wird.

**5. Verstärkende Verhaltensweisen**  
- Beine zusammen (Beinenge)  
- Körper abwenden

**6. Gegenläufige Verhaltensweisen**  
- offene Beinhaltung, Schritt-Präsentation

**7. Beispiele**  
[in Arbeit]

**8. Sonstiges**  
Bei Chase Hughes CHEM: Groin Shield, Gs, 102

**9. Literatur**  
- CHEM2017 S. 60
