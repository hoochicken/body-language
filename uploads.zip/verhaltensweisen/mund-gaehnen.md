## Gähnen

**1. Definition / Beschreibung**  
Weites Öffnen des Mundes mit tiefer Einatmung; kann kurz oder länglich ausfallen.

**2. Bedeutung**  
- oft Müdigkeit/Langeweile  
- auch möglich: Ängstlichkeit oder (in Kombination) Täuschungsindikator

**3. Varianten**  
[in Arbeit]

**4. Hintergrund**  
Gähnen befeuchtet den Mund (Druck auf Speicheldrüsen) und erhöht kurzfristig O₂-Aufnahme; Stress trocknet die Mundschleimhaut. „Langeweile-Gähnen“ dauert tendenziell länger als „Stress-Gähnen“.

**5. Verstärkende Verhaltensweisen**  
- wässrige Augen  
- gestreckter Oberkörper  
- Abwendung des Blicks

**6. Gegenläufige Verhaltensweisen**  
- wache Mimik  
- anhaltender Blickkontakt

**7. Beispiele**  
[in Arbeit]

**8. Sonstiges**  
Bei Chase Hughes CHEM: Yawn, Ym, 12

**9. Literatur**  
- CHEM2017 S. 31  
- JNML2013 S. 61
