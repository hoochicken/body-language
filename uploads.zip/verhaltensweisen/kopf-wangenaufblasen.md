## Wangenaufblasen  

**1. Definition / Beschreibung**  
Das Aufblasen der Wangen mit anschließendem Ausatmen.  

**2. Bedeutung**  
- Stressabbau  
- Selbstberuhigung nach einer belastenden Situation  

**3. Varianten**  
[noch in Arbeit]  

**4. Hintergrund**  
Typische Geste nach knapp vermiedenen Gefahren oder unglücklichen Ereignissen.  

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]  

**6. Gegenläufige Verhaltensweisen**  
[in Arbeit]  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei JNML2013: Wangenaufblasen  

**9. Literatur**  
- JNML2013 S. 57  
