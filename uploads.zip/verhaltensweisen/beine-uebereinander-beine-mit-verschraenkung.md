## Übereinander Beine mit Verschränkung  

**1. Definition / Beschreibung**  
Klassisch übereinandergeschlagene Beine, zusätzlich wird der Fuß/Knöchel um das andere Bein „geschlungen“.

**2. Bedeutung**  
- Zurückhalten, Verschleiern  
- erhöhte innere Spannung

**3. Varianten**  
[in Arbeit]

**4. Hintergrund**  
Deutlich andere Bedeutung als „Ziffer Vier“ oder klassisches Übereinanderschlagen ohne Umschlingen.

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]

**6. Gegenläufige Verhaltensweisen**  
- lockeres Überschlagen ohne Umschlingen  
- Beine parallel/neutral

**7. Beispiele**  
[in Arbeit]

**8. Sonstiges**  
Bei Chase Hughes CHEM: Double-Leg Cross, Dc, 63

**9. Literatur**  
- CHEM2017 S. 49
