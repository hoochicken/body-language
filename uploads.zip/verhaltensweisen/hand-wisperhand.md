## Wisperhand  

**1. Definition / Beschreibung**  
Die Hand wird (teil-)vor den Mund/Nase geführt.

**2. Bedeutung**  
- Nervosität/Befangenheit über das Gesagte/Gedachte  
- Impulskontrolle („etwas nicht sagen wollen“)  

**3. Varianten**  
- Mund mit Hand bedecken  
- Lippen mit Fingern bedecken  
- Nase kratzen/berühren

**4. Hintergrund**  
„Hushing“ dämpft symbolisch den Output oder markiert Unsicherheit zum Inhalt.

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]

**6. Gegenläufige Verhaltensweisen**  
- freie, offene Mundpartie ohne Abdeckung

**7. Beispiele**  
[in Arbeit]

**8. Sonstiges**  
Bei Chase Hughes CHEM: Hushing, Hu, 74

**9. Literatur**  
- CHEM2017 S. 52  
- JNML2013 S. 57
