## Fußrückzieher  

**1. Definition / Beschreibung**  
Im Sitzen werden die Füße plötzlich zurückgezogen (oft unter die Sitzfläche).  

**2. Bedeutung**  
- plötzliches Zurückhalten/Vertrauensverlust  
- Befangenheit, Unsicherheit  

**3. Varianten**  
[in Arbeit]  

**4. Hintergrund**  
Zeitlicher Bezug zum Gesagten ist zentral (Frage/Aussage).  

**5. Verstärkende Verhaltensweisen**  
- Beinenge  
- Torsodrehung weg vom Gegenüber  

**6. Gegenläufige Verhaltensweisen**  
- entspannte Fußhaltung vor dem Stuhl  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Foot Withdrawal, Fw, 91  

**9. Literatur**  
- CHEM2017 S. 57  
- JNML2013 S. 96  
