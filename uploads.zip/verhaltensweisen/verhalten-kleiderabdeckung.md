## Kleiderabdeckung  

**1. Definition / Beschreibung**  
Kleidung wird so justiert, dass mehr Körper bedeckt wird (Rock/Top nach unten ziehen, Ärmel/Decolleté anpassen).  

**2. Bedeutung**  
- Bedürfnis nach Bedeckung/Schutz  
- Scham/Unsicherheit  
- Temperatur kann Rolle spielen  

**3. Varianten**  
[in Arbeit]  

**4. Hintergrund**  
Verdeckt vitale/ intime Bereiche; steigert subjektive Sicherheit.  

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]  

**6. Gegenläufige Verhaltensweisen**  
- Öffnen/Lockerung der Kleidung  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Clothing Covering, Cc, 99  

**9. Literatur**  
- CHEM2017 S. 59  
