## Barriere durch ein Objekt  

**1. Definition / Beschreibung**  
Ein Objekt wird zwischen Körper und Gegenüber platziert/gehalten (Buch, Glas, Clipboard, Tasche, Smartphone).  

**2. Bedeutung**  
- Unsicherheit  
- Schutzbedürfnis  
- soziale Zurückhaltung  

**3. Varianten**  
[in Arbeit]  

**4. Hintergrund**  
Objekt-Barrieren erschweren Rapport. Spiegelbarrieren können bewusst entfernt werden, um Gegenüber zur Entfernung der eigenen Barriere anzuregen.  

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]  

**6. Gegenläufige Verhaltensweisen**  
- leere Hände, freie Körpervorderseite  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Object Barrier, Ob, 100  

**9. Literatur**  
- CHEM2017 S. 59  
