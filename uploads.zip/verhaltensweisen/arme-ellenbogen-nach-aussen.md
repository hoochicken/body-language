## Ellenbogen nach außen  

**1. Definition / Beschreibung**  
Die Ellenbogen bewegen sich seitlich nach außen.  

**2. Bedeutung**  
- offene Geste, signalisiert Sicherheit  
- zeigt Selbstvertrauen oder Überlegenheit  

**3. Varianten**  
- Ellenbogen leicht nach außen, weniger als Schulterbreite  
- ein einzelner Ellenbogen stößt nach außen  
- Ellenbogen weiter als Schulterbreite nach außen  

**4. Hintergrund**  
Das Exponieren lebenswichtiger Organe ist ein Zeichen von Sicherheit. Wenn es plötzlich auftritt, kann es anzeigen, dass die Person denkt, sie habe eine Hürde überwunden.  

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]  

**6. Gegenläufige Verhaltensweisen**  
- Ellenbogen nah am Körper (Schutzhaltung)  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Elbows Out, Eo, 43  

**9. Literatur**  
- CHEM2017 S. 42  
