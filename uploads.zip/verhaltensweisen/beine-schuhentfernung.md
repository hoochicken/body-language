## Schuhentfernung  

**1. Definition / Beschreibung**  
Schuhe/Sandalen werden (teilweise/komplett) ausgezogen oder es wird unbewusst an ihnen manipuliert.  

**2. Bedeutung**  
- Komfort, Vertrauen  
- Entspannung  

**3. Varianten**  
[in Arbeit]  

**4. Hintergrund**  
Komplettes Ausziehen ist ein starker Komfortmarker; partielles Lösen zeigt aufkommende Entspannung.  

**5. Verstärkende Verhaltensweisen**  
- zurückgelehnte Haltung  
- positive Mimik  

**6. Gegenläufige Verhaltensweisen**  
- Füße fest am Boden, Schuhe geschlossen  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Shoe Removal, Sr, 95  

**9. Literatur**  
- CHEM2017 S. 58  
