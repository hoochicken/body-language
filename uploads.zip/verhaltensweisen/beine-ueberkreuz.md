## Beine überkreuz  

**1. Definition / Beschreibung**  
Klassisches Überkreuzen eines Knies über das andere, Beine bleiben relativ zusammen.

**2. Bedeutung**  
- Vertrauen, Behagen  
- Zuwendung gegenüber vertrauten Personen

**3. Varianten**  
[in Arbeit]

**4. Hintergrund**  
Wichtige Baseline-Geste im Sitzen. Das Ausbleiben der Geste bei sonstiger Gewohnheit kann auf Distanz hindeuten.

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]

**6. Gegenläufige Verhaltensweisen**  
- Beine ungekreuzt/abgewandt

**7. Beispiele**  
[in Arbeit]

**8. Sonstiges**  
Bei Chase Hughes CHEM: Leg Crossing, Lg, 76

**9. Literatur**  
- CHEM2017 S. 52
