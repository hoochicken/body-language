## Einseitiges Armumschlingen  

**1. Definition / Beschreibung**  
Ein Arm umschlingt den mittleren Körperbereich.  

**2. Bedeutung**  
- Befangenheit  
- Unsicherheit  
- Schutzbedürfnis  

**3. Varianten**  
[in Arbeit]  

**4. Hintergrund**  
Häufig bei Frauen in neuen oder bedrohlichen sozialen Situationen (z. B. Studienanfang).  

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]  

**6. Gegenläufige Verhaltensweisen**  
- offene, entspannte Armhaltung  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Single Arm Wrap, Wp, 53  

**9. Literatur**  
- CHEM2017 S. 46  
