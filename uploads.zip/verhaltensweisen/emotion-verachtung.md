## Verachtung  

**1. Definition / Beschreibung**  
Universaler Gesichtsausdruck, oft asymmetrisch auf einer Gesichtshälfte stärker ausgeprägt.  

**2. Bedeutung**  
- moralische oder soziale Überlegenheit  
- Selbstsicherheit, oft herablassend  

**3. Varianten**  
[in Arbeit]  

**4. Hintergrund**  
Einziger universeller Ausdruck mit klarer Asymmetrie. In Medien/Serien oft als Erkennungsmerkmal eingesetzt; kulturelle Konnotationen können variieren.  

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]  

**6. Gegenläufige Verhaltensweisen**  
[in Arbeit]  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Contempt, Co, 33  

**9. Literatur**  
- CHEM2017 S. 39  
