## Beinenge  

**1. Definition / Beschreibung**  
Beide Beine werden (wiederholt) zusammengeführt, halten engen Kontakt, zeigen keine Entspannung.  

**2. Bedeutung**  
- Geheimnistuerei  
- Furcht/Angst  
- Sorge, Misstrauen  

**3. Varianten**  
[in Arbeit]  

**4. Hintergrund**  
„Schließen“ der unteren Körperhälfte ist eine klassische Schutz- und Zurückhaltungsgeste.  

**5. Verstärkende Verhaltensweisen**  
- Genitalschutz  
- Fußrückzug unter den Stuhl  

**6. Gegenläufige Verhaltensweisen**  
- lockere, offene Bein- und Fußstellung  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Binding Legs, Bl, 83  

**9. Literatur**  
- CHEM2017 S. 54  
