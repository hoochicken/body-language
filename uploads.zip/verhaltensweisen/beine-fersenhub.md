## Fersenhub  

**1. Definition / Beschreibung**  
Verlagern des Gewichts auf die Ballen, dabei werden die Fersen angehoben.  

**2. Bedeutung**  
- Bereitschaft zum Gehen  
- Zeitmangel oder Ungeduld  
- Stress oder Ausweichbedürfnis  

**3. Varianten**  
[noch in Arbeit]  

**4. Hintergrund**  
Signalisiert Vorbereitung auf Bewegung; häufig bei Personen, die eine Konversation beenden wollen.  

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]  

**6. Gegenläufige Verhaltensweisen**  
- fester, entspannter Stand mit voller Fußauflage  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei JNML2013: Fersenhub  

**9. Literatur**  
- JNML2013  
