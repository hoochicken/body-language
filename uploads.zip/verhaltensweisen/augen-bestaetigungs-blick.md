## Bestätigungs-Blick

**1. Definition / Beschreibung**  
Nach einer Aussage sucht die Person Blickkontakt, um Akzeptanz/Verständnis zu prüfen.

**2. Bedeutung**  
- Bedürfnis nach sozialer Bestätigung  
- Testen, ob die Geschichte geglaubt wurde (besonders nach Aussagen/Antworten)

**3. Varianten**  
[in Arbeit]

**4. Hintergrund**  
In Gruppen richtet sich der Blick oft zur einflussreichsten Person („Alpha“). In Vernehmungen kann dies als Romancing/Absicherungsversuch erscheinen.

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]

**6. Gegenläufige Verhaltensweisen**  
[in Arbeit]

**7. Beispiele**  
[in Arbeit]

**8. Sonstiges**  
Bei Chase Hughes CHEM: Confirmation Glance, Cg, 11

**9. Literatur**  
- CHEM2017 S. 30
