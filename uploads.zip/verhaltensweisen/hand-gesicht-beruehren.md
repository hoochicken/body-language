## Gesicht berühren  

**1. Definition / Beschreibung**  
Die Hand berührt Teile des Gesichts.  

**2. Bedeutung**  
- häufig in Studien mit Täuschung assoziiert  
- in Vernehmungen nur relevant in Kombination mit weiteren Stress- oder Täuschungssignalen  

**3. Varianten**  
[in Arbeit]  

**4. Hintergrund**  
Das Berühren des Gesichts ist bei niedrigem Stresslevel (Studien) häufiger, in Hochstresssituationen (Vernehmung) tritt es seltener auf.  

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]  

**6. Gegenläufige Verhaltensweisen**  
[in Arbeit]  

**7. Beispiele**  
[in Arbeit]  

**8. Sonstiges**  
Bei Chase Hughes CHEM: Facial Touching, Ft, 55  

**9. Literatur**  
- CHEM2017 S. 46  
