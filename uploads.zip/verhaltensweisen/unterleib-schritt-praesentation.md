## Schritt-Präsentation  

**1. Definition / Beschreibung**  
Die Innenseiten der Oberschenkel werden zum Gegenüber geöffnet/exponiert.

**2. Bedeutung**  
- Vertrauen, Verletzlichkeit  
- Ehrlichkeit, Bereitschaft zur Offenheit

**3. Varianten**  
[in Arbeit]

**4. Hintergrund**  
Offene Beinhaltung ist ein starkes Signal für Komfort und fehlende Abwehr.

**5. Verstärkende Verhaltensweisen**  
[in Arbeit]

**6. Gegenläufige Verhaltensweisen**  
- Genitalschutz  
- Beine geschlossen, abgewandt

**7. Beispiele**  
[in Arbeit]

**8. Sonstiges**  
Bei Chase Hughes CHEM: Groin Exposure, Ge, 75

**9. Literatur**  
- CHEM2017 S. 52
